package com.project.reportcardmanagement.controller;

public class StudentMenu {

    public void menu(int studentId) {
        System.out.println("---- STUDENT MENU ----");
        System.out.println("Student ID: " + studentId);
        System.out.println("1. View My Report Card");
        System.out.println("2. View Grades & Remarks");
    }
}